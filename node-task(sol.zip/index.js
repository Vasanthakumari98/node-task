const bodyParser = require('body-parser');
const express = require('express');
const app = express();


const mongoose = require('mongoose');
const teamRoutes = require('./routes/teamRoutes');
app.use('/teams', teamRoutes);
const PORT = process.env.PORT || 3000;



mongoose.connect(MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log('Connected to MongoDB');
        // Start the server
        app.listen(PORT, () => {
            console.log(`Server is running on port ${PORT}`);
        });
    })
    .catch(error => console.error('Error connecting to MongoDB:', error));
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/fantasy-cricket';

const port = 3000;
app.use(bodyParser.json())
// Database Details
const DB_USER = process.env['kumarimedaboina'];
const DB_PWD = process.env['6bnbZLdCnjkUF0Rs'];
const DB_URL = process.env['DB_URL'];
const DB_NAME = "task-jeff";
const DB_COLLECTION_NAME = "players";

const { MongoClient, ServerApiVersion, ObjectId } = require('mongodb');
const uri = "mongodb+srv://kumarimedaboina:6bnbZLdCnjkUF0Rs@vasantha.mcuf0ki.mongodb.net/?retryWrites=true&w=majority&appName=task-jeff";


const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  }
});

let db;

async function run() {
  try {
    await client.connect();
    await client.db("admin").command({ ping: 1 });

    db = client.db(DB_NAME);
    
    console.log("You successfully connected to MongoDB!");
    
  } finally {
  }
}


// Sample create document
async function sampleCreate() {
  const demo_doc = { 
    "demo": "doc demo",
    "hello": "world"
  };
  const demo_create = await db.collection(DB_COLLECTION_NAME).insertOne(demo_doc);
  
  console.log("Added!")
  console.log(demo_create.insertedId);
}


// Endpoints
// ​http://localhost:3000
// get---> output-->Hello World!
app.get('/', async (req, res) => {
  res.send('Hello World!');
});

app.get('/demo', async (req, res) => {
  await sampleCreate();
  res.send({status: 1, message: "demo"});
});
// get--->​http://localhost:3000/demo
// out put-->
/*{
  "status": 1,
   "message": "demo"
}
*/
app.get('/getAllData', (req, res) => {
  db.collection(DB_COLLECTION_NAME).find().toArray()
    .then(data => {
      res.json(data);
    })
    .catch(error => {
      console.error('Error retrieving data:', error);
      res.status(500).send('Error retrieving data');
    });
});
app.post("/create", async (req, res) => {
  try {
    const data  = req.body;
    console.log("post",data)
    await db.collection(DB_COLLECTION_NAME).insertOne(data);
    res.json({ success: true, message: "Data saved successfully" });
  } catch (error) {
    console.error("Error creating document:", error);
    res.status(500).json({ success: false, message: "sucess to save data" });
  }
});

// Update
app.put("/update/:id", async (req, res) => {
  try {
    const id = new ObjectId(req.params.id);
    const newData = req.body;
    console.log("update",id,newData)
    await db.collection(DB_COLLECTION_NAME).updateOne({ _id: id }, { $set: newData });
    res.json({ success: true, message: "Data updated successfully" });
  } catch (error) {
    console.error("Error updating document:", error);
    res.status(500).json({ success: false, message: "Failed to update data" });
  }
});

// // http://localhost:3000​/update
app.delete("/delete/:id", async (req, res) => {
  try {
    const id = new ObjectId(req.params.id);
    
    console.log("delete",id)
    await db.collection(DB_COLLECTION_NAME).deleteOne({ _id: id });
    res.json({ success: true, message: "Data delete successfully" });
  } catch (error) {
    console.error("Error delete document:", error);
    res.status(500).json({ success: false, message: "Failed to delete data" });
  }
});

app.listen(port, () => {
  console.log(`App listening on port ${port}`);
});

run();